package com.example.sahil.imagetotext;

import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class Main2Activity extends AppCompatActivity {

    TextView message;
    String messageText;
    Button startButton,stopButton,saveButton;
    TextToSpeech textToSpeech;
    int result;
    String text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        messageText = getIntent().getStringExtra("temp");
        message = (TextView)findViewById(R.id.textMessage);

        startButton = (Button) findViewById(R.id.start);
        stopButton = (Button) findViewById(R.id.stop);
        saveButton = (Button) findViewById(R.id.bsaveFile);
        message.setText(messageText);
        textToSpeech = new TextToSpeech(Main2Activity.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (i == TextToSpeech.SUCCESS){
                    result = textToSpeech.setLanguage(Locale.ENGLISH);
                }
                else {
                    Toast.makeText(Main2Activity.this,"Feature not supported by your phone",Toast.LENGTH_LONG).show();
                }
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Main2Activity.this,fileSave.class);
                intent.putExtra("file",message.getText().toString());
                startActivity(intent);
            }
        });

}



    public void TTS(View view) {
        switch (view.getId()){
            case R.id.start:
                if (result==TextToSpeech.LANG_MISSING_DATA || result==TextToSpeech.LANG_NOT_SUPPORTED){
                    Toast.makeText(Main2Activity.this,"Feature not supported in your device",Toast.LENGTH_LONG).show();
                }
                else {
                    text = message.getText().toString();
                    textToSpeech.speak(text,TextToSpeech.QUEUE_FLUSH,null);
                }
                break;
            case R.id.stop:
                if (textToSpeech!=null){
                    textToSpeech.stop();
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (textToSpeech!=null){
            textToSpeech.stop();
            textToSpeech.shutdown();
        }

    }
}

