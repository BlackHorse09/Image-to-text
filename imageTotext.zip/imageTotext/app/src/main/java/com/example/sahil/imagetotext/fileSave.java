package com.example.sahil.imagetotext;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class fileSave extends AppCompatActivity {

    TextView fileName,fileContents;
    Button button;
    String textToBeSaved;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_save);

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
//
//        }



        fileName = (TextView)findViewById(R.id.editTextName);
        fileContents = (TextView) findViewById(R.id.textFileContents);
        button = (Button)findViewById(R.id.bsaveContents);

        textToBeSaved = getIntent().getStringExtra("file");


    }
}
